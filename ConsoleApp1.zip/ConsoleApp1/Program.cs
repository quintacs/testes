﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Paises.Com.Covid.Model;
using Newtonsoft.Json;

namespace ConsoleApp1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            RunAsync().Wait();
            Console.ReadKey();
        }


        static async Task RunAsync()
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new System.Uri("https://api.covid19api.com/dayone/country/south-africa/status/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //HttpResponseMessage response = await client.GetAsync("api/produtos/3");                
                HttpResponseMessage response = await client.GetAsync("confirmed");

                if (response.IsSuccessStatusCode)
                {  //GET
                   //Pais pais = await response.Content.ReadAsAsync<Pais>();
                    string  conteudo = await response.Content.ReadAsStringAsync();
                    List<Pais> listPais = JsonConvert.DeserializeObject<List<Pais>>(conteudo);
                    Console.WriteLine("Paises com covid ");
                    foreach (Pais pais in listPais) { 
                        Console.WriteLine("{0}\tR${1}\t{2}", pais.country, pais.countryCode, pais.cases);                        
                    }

                    Console.ReadKey();
                }
                //POST
               /* var cha = new Produto() { Nome = "Chá Verde", Preco = 1.50M, Categoria = "Bebidas" };
                response = await client.PostAsJsonAsync("api/produtos", cha);
                Console.WriteLine("Produto cha verde incluído. Tecle algo para atualizar o preço do produto.");
                Console.ReadKey();
                if (response.IsSuccessStatusCode)
                {   //PUT
                    Uri chaUrl = response.Headers.Location;
                    cha.Preco = 2.55M;   // atualiza o preco do produto
                    response = await client.PutAsJsonAsync(chaUrl, cha);
                    Console.WriteLine("Produto preço do atualizado. Tecle algo para excluir o produto");
                    Console.ReadKey();
                    //DELETE
                    response = await client.DeleteAsync(chaUrl);
                    Console.WriteLine("Produto deletado");
                    Console.ReadKey();
                }*/
            }
        }
    }
}
